#!/usr/bin/env python3
"""Figure 5: BPNN used in this study (Eq. 4): 3 lagged log-growth inputs, 6 tanh hidden units, linear output."""
import os, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyBboxPatch
plt.rcParams.update({"font.family": "DejaVu Sans", "mathtext.fontset": "cm", "font.size": 10, "pdf.fonttype": 42, "savefig.bbox": "tight"})
os.makedirs("figures", exist_ok=True)
INK, EDGE = "#1f2d3d", "#9fb3c8"
fig, ax = plt.subplots(figsize=(7.6, 5.0)); ax.set_xlim(0, 12); ax.set_ylim(-1.75, 7.3); ax.axis("off")
xin, xh, xo = 2.4, 6.0, 9.6
yin = [5.0, 3.0, 1.0]; yh = [5.75 - i * 0.95 for i in range(6)]; yo = 3.0
for a in yin:
    for b in yh: ax.plot([xin, xh], [a, b], color=EDGE, lw=0.8, zorder=1)
for b in yh: ax.plot([xh, xo], [b, yo], color=EDGE, lw=0.8, zorder=1)
def node(x, y, r, fc, ec, txt="", fs=9):
    ax.add_patch(Circle((x, y), r, fc=fc, ec=ec, lw=1.4, zorder=3))
    if txt: ax.text(x, y, txt, ha="center", va="center", fontsize=fs, color=INK, zorder=4)
for y, lab in zip(yin, [r"$g_{t-1}$", r"$g_{t-2}$", r"$g_{t-3}$"]):
    node(xin, y, 0.42, "#eaf2fb", "#2e5c8a")
    ax.text(xin - 0.62, y, lab, ha="right", va="center", fontsize=13, color=INK)
for y in yh: node(xh, y, 0.34, "#edf7ec", "#3d7a3a", r"$\tanh$", 8.5)
node(xo, yo, 0.42, "#fdf1e6", "#c0651f")
ax.text(xo + 0.62, yo, r"$\hat{g}_t$", ha="left", va="center", fontsize=14, color=INK)
# layer headers
for x, t, s in ((xin, "Input layer", r"$\mathbf{z}_t = (g_{t-1},\,g_{t-2},\,g_{t-3})$"),
                (xh, "Hidden layer", "6 units, tanh activation"),
                (xo, "Output layer", "1 unit, linear")):
    ax.text(x, 7.05, t, ha="center", va="center", fontsize=11, weight="bold", color=INK)
    ax.text(x, 6.6, s, ha="center", va="center", fontsize=9.5, color=INK)
ax.text((xin + xh) / 2, 0.05, r"weights $\mathbf{W}$, biases $\mathbf{b}_1$", ha="center", fontsize=10, color=INK)
ax.text((xh + xo) / 2 + 0.2, 1.05, r"weights $\mathbf{v}$, bias $b_2$", ha="center", fontsize=10, color=INK)
ax.add_patch(FancyBboxPatch((0.4, -1.6), 11.2, 1.15, boxstyle="round,pad=0.02,rounding_size=0.08", fc="#f7f7f7", ec="#6b6b6b", lw=1))
ax.text(6.0, -0.78, r"$\hat{g}_t = \mathbf{v}^{\top}\tanh(\mathbf{W}\mathbf{z}_t + \mathbf{b}_1) + b_2$   [Eq. (4)]", ha="center", va="center", fontsize=11, color=INK)
ax.text(6.0, -1.3, "Trained with L-BFGS and an L2 penalty of 1.0; forecasts averaged over five random seeds", ha="center", va="center", fontsize=9, color=INK)
fig.savefig("figures/Fig05_BPNN.pdf"); fig.savefig("figures/Fig05_BPNN.png", dpi=600); plt.close(fig)
print("done")
