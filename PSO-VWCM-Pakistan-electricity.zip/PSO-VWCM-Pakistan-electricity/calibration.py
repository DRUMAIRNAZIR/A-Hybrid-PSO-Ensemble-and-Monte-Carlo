#!/usr/bin/env python3
"""Retrospective coverage of the Stage-2 90% intervals at origins 2007-2023 (h = 1..5)."""
import numpy as np, pandas as pd
from stage2_mc_core import estimate, simulate
M = "PSO-VWCM (beta=0.5)"
R = pd.read_csv("combined_forecasts.csv"); nat = R.groupby(["origin", "h", "target"])[[M, "y"]].sum().reset_index()
nat["le"] = np.log(nat.y / nat[M]); hist = pd.read_csv("history.csv"); rows = []
for T in range(2007, 2024):
    hT = hist[hist.year <= T]; fit = estimate(hT); path = nat[nat.origin == T].set_index("target")[M]
    past = nat[nat.target <= T]; sd = past.groupby("h").le.std().dropna()
    k = float(np.sum(sd * np.sqrt(sd.index)) / np.sum(sd.index))          # uses only errors known at T
    rng = np.random.default_rng(T)
    a = simulate(fit, hT, path, 5000, 0.0, rng); b = simulate(fit, hT, path, 5000, 0.0, rng, k=k)
    for yr in path.index:
        y = float(nat[(nat.origin == T) & (nat.target == yr)].y.iloc[0])
        qa, qb = np.percentile(a[yr], [5, 95]), np.percentile(b[yr], [5, 95])
        rows.append(dict(origin=T, h=yr - T, target=yr, actual=y, mc_lo=qa[0], mc_hi=qa[1], cov_mc=qa[0] <= y <= qa[1],
                         c_lo=qb[0], c_hi=qb[1], cov_comb=qb[0] <= y <= qb[1]))
C = pd.DataFrame(rows); C.to_csv("calibration.csv", index=False)
g = C.groupby("h").agg(n=("cov_mc", "size"), MC_only=("cov_mc", "mean"), MC_plus_stage1=("cov_comb", "mean"))
print(g.round(2).to_string()); print("all:", round(C.cov_mc.mean(), 2), round(C.cov_comb.mean(), 2))
