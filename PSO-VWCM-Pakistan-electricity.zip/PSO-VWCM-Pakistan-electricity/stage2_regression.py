#!/usr/bin/env python3
"""Table 9 and robustness (Table 9b): OLS with Newey-West HAC(1) on first differences of national grid
consumption (sum of six sectors, PES Table 14.1/12.1) and ERA5 heat indices. Writes history.csv and table9_robustness.csv."""
import numpy as np, pandas as pd, statsmodels.api as sm
S = ["res", "com", "ind", "agr", "sl", "og"]
d = pd.read_csv("sector_data_harmonised.csv").set_index("year")
c = pd.read_csv("pakistan_electricity_plus_extremes_1974_2024.csv").set_index("year")     # ERA5 indices
dy = pd.read_csv("daily_timeseries_1974_2024.csv", parse_dates=["date"])                  # ERA5 daily
dy["fy"] = dy.date.dt.year + (dy.date.dt.month >= 7)
D = pd.DataFrame({"elec": d.loc[1974:2024, S].sum(axis=1), "txx": c.TXx_C, "t95": c.T95_C, "cdd": c.CDD_total_degC_day,
                  "hwd": c.HWD_days, "txx_fy": dy.groupby("fy").tmax_C.max(), "lpop": 100 * np.log(d["pop_wb"])}).loc[1974:2024]
D[["elec", "txx"]].reset_index().rename(columns={"index": "year"}).to_csv("history.csv", index=False)
def run(label, heat="txx", end=2024, lag=True, pop=False):
    x = D.loc[:end].diff(); X = pd.DataFrame({"heat": x[heat]})
    if lag: X["heat_lag"] = x[heat].shift(1)
    if pop: X["dlpop"] = x["lpop"]
    Z = pd.concat([x.elec, X], axis=1).dropna()
    f = sm.OLS(Z.elec, sm.add_constant(Z.drop(columns="elec"))).fit(cov_type="HAC", cov_kwds={"maxlags": 1})
    r = {"model": label, "n": int(f.nobs), "sample": f"{Z.index.min()}-{Z.index.max()}", "b0": f.params["const"], "p0": f.pvalues["const"],
         "b1": f.params["heat"], "se1": f.bse["heat"], "p1": f.pvalues["heat"],
         "b2": f.params.get("heat_lag", np.nan), "se2": f.bse.get("heat_lag", np.nan), "p2": f.pvalues.get("heat_lag", np.nan),
         "bpop": f.params.get("dlpop", np.nan), "ppop": f.pvalues.get("dlpop", np.nan), "R2": f.rsquared, "adjR2": f.rsquared_adj,
         "resid_sd": np.sqrt(f.scale)}
    return r
rows = [run("(1) Main: TXx, 1974-2024"), run("(2) Sample to 2022", end=2022), run("(3) + population growth (WDI)", pop=True),
        run("(4) No lag", lag=False), run("(5) T95 instead of TXx", heat="t95"), run("(6) CDD instead of TXx", heat="cdd"),
        run("(7) Heatwave days instead of TXx", heat="hwd"), run("(8) Fiscal-year TXx (Jul-Jun)", heat="txx_fy")]
T = pd.DataFrame(rows); T.round(4).to_csv("table9_robustness.csv", index=False); print(T.round(3).to_string())
