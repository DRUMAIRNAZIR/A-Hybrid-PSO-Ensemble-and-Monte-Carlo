
**Table 3. Residential sector: out-of-sample forecast accuracy**

|                 | SVR     | BPNN    | LSTM    | Holt    | ARIMA   | Grey     | PSO-VWCM   | Equal wts   | RW-drift   |
|:----------------|:--------|:--------|:--------|:--------|:--------|:---------|:-----------|:------------|:-----------|
| MAE (GWh), h=1  | 2,665.9 | 2,049.4 | 2,375.0 | 1,807.1 | 1,904.8 | 21,613.9 | 1,941.3    | 4,515.1     | 3,289.2    |
| RMSE (GWh), h=1 | 3,307.9 | 2,580.4 | 2,795.7 | 2,236.4 | 2,534.7 | 22,317.9 | 2,349.8    | 5,152.5     | 3,998.5    |
| MAPE (%), h=1   | 6.03    | 4.62    | 5.23    | 4.00    | 4.30    | 48.53    | 4.29       | 10.24       | 7.39       |
| NRMSE, h=1      | 0.125   | 0.098   | 0.106   | 0.085   | 0.096   | 0.844    | 0.089      | 0.195       | 0.151      |
| RAE, h=1        | 0.810   | 0.623   | 0.722   | 0.549   | 0.579   | 6.571    | 0.590      | 1.373       | 1.000      |
| MAPE (%), h=1–5 | 14.47   | 10.71   | 9.96    | 8.22    | 11.34   | 56.17    | 8.78       | 15.55       | 21.53      |
| RAE, h=1–5      | 0.660   | 0.501   | 0.467   | 0.389   | 0.541   | 2.588    | 0.414      | 0.711       | 1.000      |
| Weight at 2024  | 0.000   | 0.000   | 0.244   | 0.755   | 0.000   | 0.000    | —          | —           | —          |

*Note.* Out-of-sample forecasts from expanding-window origins 2007–2023 (h=1: n=17; h=1–5 pooled: n=75). NRMSE = RMSE/(max − min of actuals); RAE = Σ|e| / Σ|e of RW-drift|. Weights are non-negative and sum to one; a zero weight means the model is excluded.


**Table 4. Agricultural sector: out-of-sample forecast accuracy**

|                 | SVR   | BPNN   | LSTM    | Holt   | ARIMA   | Grey    | PSO-VWCM   | Equal wts   | RW-drift   |
|:----------------|:------|:-------|:--------|:-------|:--------|:--------|:-----------|:------------|:-----------|
| MAE (GWh), h=1  | 667.8 | 593.3  | 1,144.5 | 590.4  | 617.9   | 1,696.4 | 667.9      | 679.1       | 617.9      |
| RMSE (GWh), h=1 | 779.0 | 741.1  | 1,403.0 | 705.6  | 766.3   | 1,929.0 | 779.1      | 861.6       | 766.3      |
| MAPE (%), h=1   | 7.53  | 6.67   | 12.83   | 6.67   | 6.96    | 19.19   | 7.53       | 7.71        | 6.96       |
| NRMSE, h=1      | 0.306 | 0.291  | 0.550   | 0.277  | 0.301   | 0.756   | 0.306      | 0.338       | 0.301      |
| RAE, h=1        | 1.081 | 0.960  | 1.852   | 0.955  | 1.000   | 2.745   | 1.081      | 1.099       | 1.000      |
| MAPE (%), h=1–5 | 16.77 | 15.46  | 24.44   | 14.76  | 16.32   | 25.59   | 16.77      | 16.70       | 16.33      |
| RAE, h=1–5      | 1.032 | 0.963  | 1.498   | 0.900  | 1.000   | 1.600   | 1.033      | 1.019       | 1.000      |
| Weight at 2024  | 1.000 | 0.000  | 0.000   | 0.000  | 0.000   | 0.000   | —          | —           | —          |

*Note.* Out-of-sample forecasts from expanding-window origins 2007–2023 (h=1: n=17; h=1–5 pooled: n=75). NRMSE = RMSE/(max − min of actuals); RAE = Σ|e| / Σ|e of RW-drift|. Weights are non-negative and sum to one; a zero weight means the model is excluded.


**Table 5. Commercial sector: out-of-sample forecast accuracy**

|                 | SVR   | BPNN   | LSTM    | Holt   | ARIMA   | Grey    | PSO-VWCM   | Equal wts   | RW-drift   |
|:----------------|:------|:-------|:--------|:-------|:--------|:--------|:-----------|:------------|:-----------|
| MAE (GWh), h=1  | 382.7 | 392.8  | 733.9   | 389.7  | 413.5   | 924.6   | 747.4      | 470.0       | 330.5      |
| RMSE (GWh), h=1 | 539.1 | 519.6  | 1,070.2 | 512.8  | 501.8   | 1,173.7 | 940.8      | 587.2       | 434.7      |
| MAPE (%), h=1   | 5.57  | 5.73   | 10.33   | 5.83   | 5.85    | 12.01   | 9.86       | 6.55        | 4.70       |
| NRMSE, h=1      | 0.137 | 0.132  | 0.271   | 0.130  | 0.127   | 0.298   | 0.239      | 0.149       | 0.110      |
| RAE, h=1        | 1.158 | 1.189  | 2.221   | 1.179  | 1.251   | 2.798   | 2.262      | 1.422       | 1.000      |
| MAPE (%), h=1–5 | 16.82 | 12.37  | 19.55   | 14.11  | 12.86   | 14.05   | 16.41      | 13.90       | 11.85      |
| RAE, h=1–5      | 1.407 | 1.027  | 1.690   | 1.109  | 1.085   | 1.274   | 1.408      | 1.170       | 1.000      |
| Weight at 2024  | 0.042 | 0.032  | 0.000   | 0.211  | 0.000   | 0.716   | —          | —           | —          |

*Note.* Out-of-sample forecasts from expanding-window origins 2007–2023 (h=1: n=17; h=1–5 pooled: n=75). NRMSE = RMSE/(max − min of actuals); RAE = Σ|e| / Σ|e of RW-drift|. Weights are non-negative and sum to one; a zero weight means the model is excluded.


**Table 6. Industrial sector: out-of-sample forecast accuracy**

|                 | SVR     | BPNN    | LSTM    | Holt    | ARIMA   | Grey    | PSO-VWCM   | Equal wts   | RW-drift   |
|:----------------|:--------|:--------|:--------|:--------|:--------|:--------|:-----------|:------------|:-----------|
| MAE (GWh), h=1  | 1,880.3 | 1,789.0 | 2,823.2 | 1,858.8 | 1,883.1 | 3,920.8 | 1,963.1    | 1,953.0     | 1,657.4    |
| RMSE (GWh), h=1 | 2,321.6 | 2,320.4 | 3,317.9 | 2,397.8 | 2,397.5 | 4,262.8 | 2,468.4    | 2,450.0     | 2,170.9    |
| MAPE (%), h=1   | 7.37    | 7.15    | 11.17   | 7.32    | 7.37    | 15.95   | 7.68       | 7.73        | 6.58       |
| NRMSE, h=1      | 0.189   | 0.189   | 0.270   | 0.195   | 0.195   | 0.347   | 0.201      | 0.200       | 0.177      |
| RAE, h=1        | 1.134   | 1.079   | 1.703   | 1.121   | 1.136   | 2.366   | 1.184      | 1.178       | 1.000      |
| MAPE (%), h=1–5 | 10.88   | 10.29   | 21.71   | 11.84   | 10.20   | 19.27   | 11.46      | 11.73       | 9.39       |
| RAE, h=1–5      | 1.202   | 1.118   | 2.384   | 1.285   | 1.107   | 2.055   | 1.245      | 1.280       | 1.000      |
| Weight at 2024  | 0.000   | 0.000   | 0.002   | 0.010   | 0.967   | 0.021   | —          | —           | —          |

*Note.* Out-of-sample forecasts from expanding-window origins 2007–2023 (h=1: n=17; h=1–5 pooled: n=75). NRMSE = RMSE/(max − min of actuals); RAE = Σ|e| / Σ|e of RW-drift|. Weights are non-negative and sum to one; a zero weight means the model is excluded.


**Table 7. Street lighting sector: out-of-sample forecast accuracy**

|                 | SVR   | BPNN   | LSTM   | Holt   | ARIMA   | Grey   | PSO-VWCM   | Equal wts   | RW-drift   |
|:----------------|:------|:-------|:-------|:-------|:--------|:-------|:-----------|:------------|:-----------|
| MAE (GWh), h=1  | 42.1  | 36.1   | 44.5   | 36.1   | 33.4    | 84.7   | 36.2       | 39.2        | 39.5       |
| RMSE (GWh), h=1 | 52.6  | 49.2   | 55.4   | 52.8   | 44.3    | 106.1  | 49.4       | 48.5        | 52.7       |
| MAPE (%), h=1   | 9.04  | 7.65   | 9.65   | 7.48   | 7.03    | 19.34  | 7.65       | 8.54        | 8.43       |
| NRMSE, h=1      | 0.195 | 0.182  | 0.205  | 0.195  | 0.164   | 0.393  | 0.183      | 0.180       | 0.195      |
| RAE, h=1        | 1.065 | 0.914  | 1.125  | 0.914  | 0.846   | 2.143  | 0.915      | 0.991       | 1.000      |
| MAPE (%), h=1–5 | 27.45 | 20.39  | 24.56  | 15.81  | 19.28   | 25.74  | 18.68      | 21.40       | 21.98      |
| RAE, h=1–5      | 1.260 | 0.938  | 1.117  | 0.751  | 0.887   | 1.128  | 0.859      | 0.974       | 1.000      |
| Weight at 2024  | 0.000 | 0.000  | 0.000  | 0.643  | 0.233   | 0.124  | —          | —           | —          |

*Note.* Out-of-sample forecasts from expanding-window origins 2007–2023 (h=1: n=17; h=1–5 pooled: n=75). NRMSE = RMSE/(max − min of actuals); RAE = Σ|e| / Σ|e of RW-drift|. Weights are non-negative and sum to one; a zero weight means the model is excluded.


**Table 8. Other government sector: out-of-sample forecast accuracy**

|                 | SVR   | BPNN   | LSTM   | Holt   | ARIMA   | Grey    | PSO-VWCM   | Equal wts   | RW-drift   |
|:----------------|:------|:-------|:-------|:-------|:--------|:--------|:-----------|:------------|:-----------|
| MAE (GWh), h=1  | 587.3 | 513.3  | 618.3  | 470.1  | 503.2   | 1,064.7 | 497.9      | 472.6       | 355.2      |
| RMSE (GWh), h=1 | 888.3 | 620.6  | 754.1  | 655.9  | 689.9   | 1,150.3 | 584.7      | 591.3       | 520.9      |
| MAPE (%), h=1   | 8.78  | 8.68   | 10.54  | 7.99   | 8.74    | 19.27   | 8.94       | 8.40        | 5.92       |
| NRMSE, h=1      | 0.155 | 0.108  | 0.131  | 0.114  | 0.120   | 0.200   | 0.102      | 0.103       | 0.091      |
| RAE, h=1        | 1.653 | 1.445  | 1.741  | 1.323  | 1.417   | 2.997   | 1.402      | 1.331       | 1.000      |
| MAPE (%), h=1–5 | 18.66 | 18.33  | 17.70  | 18.89  | 17.92   | 25.01   | 19.08      | 17.41       | 16.18      |
| RAE, h=1–5      | 1.247 | 1.111  | 1.123  | 1.176  | 1.073   | 1.412   | 1.140      | 1.037       | 1.000      |
| Weight at 2024  | 0.000 | 0.000  | 0.457  | 0.209  | 0.299   | 0.036   | —          | —           | —          |

*Note.* Out-of-sample forecasts from expanding-window origins 2007–2023 (h=1: n=17; h=1–5 pooled: n=75). NRMSE = RMSE/(max − min of actuals); RAE = Σ|e| / Σ|e of RW-drift|. Weights are non-negative and sum to one; a zero weight means the model is excluded.


**New table. National consumption (sum of six sectors): out-of-sample forecast accuracy**

|                 | SVR     | BPNN    | LSTM    | Holt    | ARIMA   | Grey     | PSO-VWCM   | Equal wts   | RW-drift   |
|:----------------|:--------|:--------|:--------|:--------|:--------|:---------|:-----------|:------------|:-----------|
| MAE (GWh), h=1  | 4,789.2 | 4,450.8 | 4,755.1 | 4,172.0 | 4,348.3 | 28,420.8 | 4,656.6    | 7,020.5     | 5,440.5    |
| RMSE (GWh), h=1 | 5,545.2 | 4,936.8 | 5,396.6 | 4,858.3 | 4,948.9 | 29,394.9 | 5,391.8    | 7,999.4     | 6,453.0    |
| MAPE (%), h=1   | 5.14    | 4.75    | 5.11    | 4.44    | 4.64    | 30.73    | 4.93       | 7.64        | 5.88       |
| NRMSE, h=1      | 0.119   | 0.106   | 0.116   | 0.105   | 0.107   | 0.633    | 0.116      | 0.172       | 0.139      |
| RAE, h=1        | 0.880   | 0.818   | 0.874   | 0.767   | 0.799   | 5.224    | 0.856      | 1.290       | 1.000      |
| MAPE (%), h=1–5 | 11.44   | 9.26    | 9.95    | 7.66    | 9.04    | 36.31    | 8.12       | 12.28       | 15.06      |
| RAE, h=1–5      | 0.759   | 0.617   | 0.675   | 0.516   | 0.608   | 2.415    | 0.540      | 0.811       | 1.000      |

*Note.* Out-of-sample forecasts from expanding-window origins 2007–2023 (h=1: n=17; h=1–5 pooled: n=75). NRMSE = RMSE/(max − min of actuals); RAE = Σ|e| / Σ|e of RW-drift|. Weights are non-negative and sum to one; a zero weight means the model is excluded.
