"""
Stage-2 simulator (revised). TXx is simulated in LEVELS, not increments.

ERA5 TXx over 1974-2024 behaves as stationary noise around a constant mean (lag-1 autocorrelation 0.17,
no significant trend; first differences have lag-1 autocorrelation -0.43). Drawing independent increments,
as the earlier script did, turns TXx into a random walk whose spread widens without bound. Here:

    TXx_t   = m + s_t + e_t,     e_t ~ N(0, sd_level^2) i.i.d.,  s_t = shift * (t - T0) / H  (scenario)
    dTXx_t  = TXx_t - TXx_{t-1}, with TXx_{T0} = last observed value
    D_t     = D_{t-1} + b1*(dTXx_t - E0[dTXx_t]) + b2*(dTXx_{t-1} - E0[dTXx_{t-1}]) + eps_t
    ELEC_t  = Yhat_t * exp(u_t) + D_t

E0[.] is the expectation under the Baseline (s_t = 0), so the Baseline median follows the Stage-1 path and a
scenario shift moves D through b1 and b2. (b0, b1, b2) are drawn from N(beta_hat, V_HAC); eps ~ N(0, s^2),
s = OLS residual s.d.; u_t ~ N(0, (k sqrt(h))^2) is Stage-1 forecast error (k from out-of-sample errors).
"""
import numpy as np, pandas as pd, statsmodels.api as sm

def estimate(hist):
    d = hist.set_index("year")[["elec", "txx"]].diff().rename(columns={"elec": "delec", "txx": "dtxx"})
    d["dtxx_lag"] = d["dtxx"].shift(1); d = d.dropna()
    fit = sm.OLS(d["delec"], sm.add_constant(d[["dtxx", "dtxx_lag"]])).fit(cov_type="HAC", cov_kwds={"maxlags": 1})
    return fit

def simulate(fit, hist, y_hat, paths, shift, rng, k=0.0, coef_uncertainty=True, return_txx=False):
    txx = hist.set_index("year")["txx"]; m, sdl = txx.mean(), txx.std(ddof=1)
    last_txx, prev_d = txx.iloc[-1], txx.iloc[-1] - txx.iloc[-2]
    years = y_hat.index.to_numpy(); H = len(years)
    B = rng.multivariate_normal(fit.params.values, fit.cov_params().values, size=paths) if coef_uncertainty \
        else np.tile(fit.params.values, (paths, 1))
    b1, b2 = B[:, 1], B[:, 2]; s_eps = np.sqrt(fit.scale)
    D = np.zeros(paths); lvl_prev = np.full(paths, last_txx); dprev = np.full(paths, prev_d)
    e_prev0 = prev_d                                   # baseline expectation of the lagged change (observed)
    out, tx = {}, {}
    for i, yr in enumerate(years):
        lvl = m + shift * (i + 1) / H + rng.normal(0, sdl, paths)
        dtxx = lvl - lvl_prev
        e0 = (m - last_txx) if i == 0 else 0.0         # baseline expected change
        D = D + b1 * (dtxx - e0) + b2 * (dprev - e_prev0) + rng.normal(0, s_eps, paths)
        u = np.exp(rng.normal(0, k * np.sqrt(i + 1), paths)) if k > 0 else 1.0
        out[yr] = y_hat.loc[yr] * u + D; tx[yr] = lvl
        lvl_prev, dprev, e_prev0 = lvl, dtxx, e0
    return (pd.DataFrame(out), pd.DataFrame(tx)) if return_txx else pd.DataFrame(out)
