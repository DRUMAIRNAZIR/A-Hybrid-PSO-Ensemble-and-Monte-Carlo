#!/usr/bin/env python3
"""
Stage 1, revised: six base forecasters, expanding-window rolling-origin evaluation,
and a PSO forecast combination whose weights are constrained to the probability simplex.

All models forecast the log level; ML models learn annual log-growth from lagged log-growth
and are iterated recursively. Horizons h = 1..H_EVAL are evaluated at every origin T
(training data end in year T, forecasts for T+1..T+h).

Weights at origin T use ONLY forecast errors whose target year is <= T (no look-ahead):
    h_m(T)  = PSO argmin over simplex of mean squared relative error of past combined forecasts
    w_m(T)  = beta * w_m(T-1) + (1 - beta) * h_m(T)                (VWCM smoothing, Eq. 13)
"""
import json, sys, warnings, time
import numpy as np, pandas as pd
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
import jax, jax.numpy as jnp, optax

warnings.filterwarnings("ignore")
SECTORS = ["res", "com", "ind", "agr", "sl", "og"]
MODELS = ["SVR", "BPNN", "LSTM", "Holt", "ARIMA", "Grey"]
FIRST_ORIGIN, LAST_ORIGIN, EVAL_FROM = 1996, 2023, 2007   # warm-up origins 1996-2006 feed the weights
H_EVAL, H_FINAL, LAGS, SEEDS = 5, 15, 3, 5
BETA = 0.5

# ---------------------------------------------------------------- base models
def f_arima(y, h):
    ly = np.log(y); best = None
    for p in range(3):
        for q in range(3):
            try:
                r = ARIMA(ly, order=(p, 1, q), trend="t").fit()
                k = p + q + 2; n = len(ly) - 1
                aicc = r.aic + 2 * k * (k + 1) / max(n - k - 1, 1)
                if best is None or aicc < best[0]: best = (aicc, r, (p, 1, q))
            except Exception:
                pass
    return np.exp(best[1].forecast(h)), {"order": best[2]}

def f_holt(y, h):
    ly = np.log(y); best = None
    for damped in (False, True):
        r = ExponentialSmoothing(ly, trend="add", damped_trend=damped, seasonal=None,
                                 initialization_method="estimated").fit()
        if best is None or r.aicc < best[0]: best = (r.aicc, r, damped)
    return np.exp(best[1].forecast(h)), {"damped": best[2],
            "alpha": float(best[1].params["smoothing_level"]), "beta": float(best[1].params["smoothing_trend"])}

def f_grey(y, h):
    x1 = np.cumsum(y); z = 0.5 * (x1[1:] + x1[:-1])
    B = np.column_stack([-z, np.ones_like(z)]); a, b = np.linalg.lstsq(B, y[1:], rcond=None)[0]
    k = np.arange(len(y), len(y) + h + 1)
    x1h = (y[0] - b / a) * np.exp(-a * (k - 1)) + b / a       # k-1 index: x1(k), k=1..n
    return np.diff(x1h)[-h:] if h > 0 else np.array([]), {"a": float(a), "b": float(b)}

def lagmat(g, p):
    X = np.column_stack([g[i:len(g) - p + i] for i in range(p)]); return X, g[p:]

def recursive(predict_one, g, y_last, h):
    hist = list(g); out = []; lvl = np.log(y_last)
    for _ in range(h):
        nxt = float(np.ravel(predict_one(np.array(hist[-LAGS:])[None, :]))[0]); hist.append(nxt); lvl += nxt; out.append(np.exp(lvl))
    return np.array(out)

SVR_GRID = [(C, e, gm) for C in (0.3, 1, 3, 10) for e in (0.05, 0.1) for gm in ("scale", 0.1)]
def f_svr(y, h):
    g = np.diff(np.log(y)); X, t = lagmat(g, LAGS)
    def fit(Xa, ta, C, e, gm):
        sx, sy = StandardScaler().fit(Xa), StandardScaler().fit(ta[:, None])
        m = SVR(C=C, epsilon=e, gamma=gm).fit(sx.transform(Xa), sy.transform(ta[:, None]).ravel())
        return lambda Z: sy.inverse_transform(m.predict(sx.transform(Z))[:, None]).ravel()
    v = 5; best = None                                           # inner chronological validation: last 5 years
    for C, e, gm in SVR_GRID:
        pr = fit(X[:-v], t[:-v], C, e, gm); err = np.mean((pr(X[-v:]) - t[-v:]) ** 2)
        if best is None or err < best[0]: best = (err, (C, e, gm))
    pr = fit(X, t, *best[1])
    return recursive(pr, g, y[-1], h), {"C": best[1][0], "epsilon": best[1][1], "gamma": best[1][2]}

def f_bpnn(y, h):
    g = np.diff(np.log(y)); X, t = lagmat(g, LAGS)
    sx, sy = StandardScaler().fit(X), StandardScaler().fit(t[:, None]); fc = []
    for s in range(SEEDS):
        m = MLPRegressor(hidden_layer_sizes=(6,), activation="tanh", solver="lbfgs", alpha=1.0,
                         max_iter=2000, random_state=s).fit(sx.transform(X), sy.transform(t[:, None]).ravel())
        pr = lambda Z, m=m: sy.inverse_transform(m.predict(sx.transform(Z))[:, None]).ravel()
        fc.append(recursive(pr, g, y[-1], h))
    fc = np.array(fc); return fc.mean(0), {"seed_sd_last": float(fc[:, -1].std())}

# --- minimal LSTM (1 layer, 8 units) in JAX
HID = 8
def lstm_init(key):
    k1, k2, k3 = jax.random.split(key, 3); s = 0.3
    return {"W": jax.random.normal(k1, (1 + HID, 4 * HID)) * s, "b": jnp.zeros(4 * HID).at[HID:2 * HID].set(1.0),
            "V": jax.random.normal(k2, (HID, 1)) * s, "c": jnp.zeros(1)}
def lstm_apply(p, X):                                  # X: (batch, LAGS)
    hs = jnp.zeros((X.shape[0], HID)); cs = jnp.zeros_like(hs)
    for t in range(X.shape[1]):
        z = jnp.concatenate([X[:, t:t + 1], hs], 1) @ p["W"] + p["b"]
        i, f, o, u = jnp.split(z, 4, 1)
        cs = jax.nn.sigmoid(f) * cs + jax.nn.sigmoid(i) * jnp.tanh(u); hs = jax.nn.sigmoid(o) * jnp.tanh(cs)
    return (hs @ p["V"] + p["c"]).ravel()
OPT = optax.adam(0.01)
@jax.jit
def lstm_step(p, s, X, t):
    loss = lambda q: jnp.mean((lstm_apply(q, X) - t) ** 2) + 1e-3 * sum(jnp.sum(v ** 2) for v in jax.tree_util.tree_leaves(q))
    l, gr = jax.value_and_grad(loss)(p); u, s = OPT.update(gr, s, p); return optax.apply_updates(p, u), s, l
_apply_jit = jax.jit(lstm_apply)
def f_lstm(y, h, epochs=300):
    g = np.diff(np.log(y)); X, t = lagmat(g, LAGS)
    mu, sd = g.mean(), g.std() + 1e-9; Xs, ts = jnp.array((X - mu) / sd), jnp.array((t - mu) / sd); fc = []
    for s in range(SEEDS):
        p = lstm_init(jax.random.PRNGKey(s)); st = OPT.init(p)
        for _ in range(epochs): p, st, _ = lstm_step(p, st, Xs, ts)
        pr = lambda Z, p=p: np.asarray(_apply_jit(p, jnp.array((Z - mu) / sd))) * sd + mu
        fc.append(recursive(pr, g, y[-1], h))
    fc = np.array(fc); return fc.mean(0), {"seed_sd_last": float(fc[:, -1].std())}

FUN = {"SVR": f_svr, "BPNN": f_bpnn, "LSTM": f_lstm, "Holt": f_holt, "ARIMA": f_arima, "Grey": f_grey}

# ---------------------------------------------------------------- PSO on the simplex
def to_simplex(x):
    x = np.clip(x, 0, None); s = x.sum(-1, keepdims=True)
    return np.where(s > 0, x / np.where(s > 0, s, 1), 1.0 / x.shape[-1])

def pso_simplex(F, Y, n_part=40, iters=200, w=0.729, c1=1.49445, c2=1.49445, seed=0):
    """F: (n_obs, M) past forecasts; Y: (n_obs,) actuals. Fitness = mean squared relative error."""
    rng = np.random.default_rng(seed); M = F.shape[1]
    fit = lambda X: np.mean(((to_simplex(X) @ F.T) / Y - 1) ** 2, axis=1)
    X = rng.random((n_part, M)); V = np.zeros_like(X)
    pb, pbf = X.copy(), fit(X); g = pb[pbf.argmin()].copy(); gf = pbf.min(); hist = [gf]
    for _ in range(iters):
        r1, r2 = rng.random(X.shape), rng.random(X.shape)
        V = w * V + c1 * r1 * (pb - X) + c2 * r2 * (g - X); X = np.clip(X + V, 0, 1)
        f = fit(X); imp = f < pbf; pb[imp], pbf[imp] = X[imp], f[imp]
        if pbf.min() < gf: gf = pbf.min(); g = pb[pbf.argmin()].copy()
        hist.append(gf)
    return to_simplex(g), gf, hist

# ---------------------------------------------------------------- driver
def run_sector(y_ser, name):
    years = y_ser.index.to_numpy(); rows = []; cfg = {}
    for T in range(FIRST_ORIGIN, LAST_ORIGIN + 1):
        y = y_ser.loc[:T].to_numpy(float); h = int(min(H_EVAL, int(years.max()) - T))
        for m in MODELS:
            fc, info = FUN[m](y, h); cfg.setdefault(m, {})[T] = info
            for k in range(h):
                rows.append((name, T, k + 1, T + k + 1, m, float(fc[k]), float(y_ser.loc[T + k + 1])))
        # naive random walk with drift benchmark
        dr = (np.log(y[-1]) - np.log(y[0])) / (len(y) - 1)
        for k in range(h): rows.append((name, T, k + 1, T + k + 1, "Naive", float(y[-1] * np.exp(dr * (k + 1))), float(y_ser.loc[T + k + 1])))
        print(name, T, flush=True)
    return pd.DataFrame(rows, columns=["sector", "origin", "h", "target", "model", "fc", "y"]), cfg

if __name__ == "__main__":
    d = pd.read_csv("sector_data_harmonised.csv").set_index("year")
    which = sys.argv[1:] or SECTORS
    for s in which:
        t0 = time.time(); df, cfg = run_sector(d[s].astype(float), s)
        df.to_csv(f"rolling_{s}.csv", index=False); json.dump(cfg, open(f"cfg_{s}.json", "w"), default=str)
        print(s, "done", round(time.time() - t0), "s", flush=True)
