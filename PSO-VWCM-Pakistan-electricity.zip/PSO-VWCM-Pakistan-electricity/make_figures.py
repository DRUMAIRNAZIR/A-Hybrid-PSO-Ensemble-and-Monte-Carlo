#!/usr/bin/env python3
"""
Regenerates all data figures (Figs 1, 9-34, S1-S2) from the final output files.
Each figure is written as vector PDF and 600-dpi PNG to ./figures/.
Inputs: sector_data_harmonised.csv, pes_supplement_2024_25_table14_1_electricity.csv, combined_forecasts.csv,
        final_forecasts_2023_2037.csv, weights.json, rolling_*.csv, table11_revised_combined.csv,
        sim_{Baseline,High-Heat,Low-Heat}.npz, calibration.csv
"""
import json, os
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
from combine import metrics, weights_path
from stage1_rolling import MODELS, SECTORS, EVAL_FROM, pso_simplex

os.makedirs("figures", exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9,
                     "legend.fontsize": 7.5, "xtick.labelsize": 8, "ytick.labelsize": 8, "axes.spines.top": False,
                     "axes.spines.right": False, "pdf.fonttype": 42, "savefig.bbox": "tight"})
# Okabe-Ito palette (colour-blind safe) plus distinct line styles so figures also read in greyscale
COL = {"SVR": "#E69F00", "BPNN": "#56B4E9", "LSTM": "#009E73", "Holt": "#0072B2", "ARIMA": "#D55E00", "Grey": "#CC79A7",
       "PSO-VWCM": "#000000", "Equal weights": "#999999", "RW-drift": "#F0E442"}
LS = {"SVR": (0, (1, 1)), "BPNN": (0, (3, 1)), "LSTM": "-", "Holt": (0, (5, 2, 1, 2)), "ARIMA": (0, (6, 2)), "Grey": (0, (2, 2))}
NAME = {"res": "Residential", "agr": "Agricultural", "com": "Commercial", "ind": "Industrial", "sl": "Street lighting",
        "og": "Other government"}
ORDER = ["res", "agr", "com", "ind", "sl", "og"]                 # manuscript order: Figs 9-26
SECCOL_LINE = {"res": "#0072B2", "ind": "#D55E00", "og": "#009E73", "com": "#CC79A7", "agr": "#E69F00", "sl": "#56B4E9"}
SECCOL = {"res": "#66c2a5", "agr": "#a6d854", "com": "#fc8d62", "ind": "#8da0cb", "sl": "#ffd92f", "og": "#e78ac3"}
FIGNO = {s: (9 + 3 * i, 10 + 3 * i, 11 + 3 * i) for i, s in enumerate(ORDER)}
M = "PSO-VWCM (beta=0.5)"

def save(fig, name):
    fig.savefig(f"figures/{name}.pdf"); fig.savefig(f"figures/{name}.png", dpi=600); plt.close(fig)

d = pd.read_csv("sector_data_harmonised.csv").set_index("year")
p25 = pd.read_csv("pes_supplement_2024_25_table14_1_electricity.csv").set_index("year").loc[2025]      # FY2025 provisional, hold-out
F = pd.read_csv("final_forecasts_2023_2037.csv", index_col=0)
R = pd.read_csv("combined_forecasts.csv"); W = json.load(open("weights.json"))["final_weights"]
T11 = pd.read_csv("table11_revised_combined.csv", index_col=0)
d["nat"] = d[SECTORS].sum(axis=1)
yrs_f = F.index.to_numpy()

def band_k(sub):
    """Out-of-sample log-error s.d. by horizon -> k in sd(h) = k*sqrt(h) (least squares)."""
    sd = np.log(sub.y / sub[M]).groupby(sub.h).std()
    return float(np.sum(sd * np.sqrt(sd.index)) / np.sum(sd.index))

# ------------------------------------------------------------------ Fig 1 (line chart: total and six sectors)
yrs = d.loc[1972:2024].index
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 3.2), gridspec_kw={"width_ratios": [1, 1.25]})
a1.plot(yrs, d.loc[1972:2024, "nat"], color="k", lw=1.5, marker="o", ms=2.2)
a1.plot(2022, d.loc[2022, "nat"], "o", mfc="white", mec="k", ms=5, label="FY2022 (Other government estimated)")
a1.set_title("(a) Total consumption, six sectors", loc="left"); a1.set_ylabel("Electricity consumption (GWh)")
a1.legend(frameon=False, loc="upper left", fontsize=7)
mk = {"res": "o", "ind": "s", "agr": "^", "com": "D", "og": "v", "sl": "x"}
for s in ["res", "ind", "og", "com", "agr", "sl"]:
    a2.plot(yrs, d.loc[1972:2024, s], color=SECCOL_LINE[s], lw=1.2, marker=mk[s], ms=2.2, markevery=4, label=NAME[s])
a2.set_title("(b) Consumption by sector", loc="left"); a2.legend(frameon=False, loc="upper left", fontsize=7)
for a in (a1, a2):
    a.set_xlim(1972, 2024); a.set_xlabel("Fiscal year (ending June)")
    a.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:,.0f}"))
fig.tight_layout(); save(fig, "Fig01_sector_consumption_1972_2024")

# ------------------------------------------------------------------ sector figures
ev = R[R.origin >= EVAL_FROM]
cols = MODELS + [M, "Equal weights", "Naive"]; lab = {M: "PSO-VWCM", "Naive": "RW-drift"}
for s in ORDER:
    fa, fb, fc = FIGNO[s]
    hist = d.loc[1972:2024, s]
    # (a) individual model forecasts
    fig, ax = plt.subplots(figsize=(6.6, 3.4))
    ax.plot(hist.index, hist, color="k", lw=1.3, label="Observed, FY1972–FY2024")
    for m in MODELS:
        ax.plot(yrs_f, F[f"{s}_{m}"], color=COL[m], ls=LS[m], lw=1.3, label=m)
    ax.plot(2025, p25[s], "D", color="k", mfc="white", ms=4.5, label="FY2025 provisional (not used in fitting)")
    ax.axvline(2024.5, color="0.6", lw=0.6)
    ax.set_xlabel("Fiscal year"); ax.set_ylabel("GWh"); ax.set_xlim(1972, 2037)
    ax.set_title(f"{NAME[s]}: component model forecasts, 2025–2037 (models fitted on FY1972–FY2024)", loc="left")
    ax.legend(ncol=3, frameon=False, loc="upper left")
    ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:,.0f}"))
    save(fig, f"Fig{fa:02d}_{s}_model_forecasts")

    # (b) out-of-sample accuracy + weights
    sub = ev[ev.sector == s]
    m1, m5 = metrics(sub[sub.h == 1], cols)["MAPE (%)"], metrics(sub, cols)["MAPE (%)"]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 3.0), gridspec_kw={"width_ratios": [1.6, 1]})
    x = np.arange(len(cols)); w = 0.38
    a1.bar(x - w / 2, m1.values, w, color="0.25", label="h = 1")
    a1.bar(x + w / 2, m5.values, w, color="0.7", hatch="///", edgecolor="0.3", lw=0.3, label="h = 1–5 pooled")
    a1.set_xticks(x, [lab.get(c, c) for c in cols], rotation=45, ha="right"); a1.set_ylabel("Out-of-sample MAPE (%)")
    a1.set_title(f"(a) Rolling-origin accuracy, origins {EVAL_FROM}–2023", loc="left"); a1.legend(frameon=False)
    wv = [W[s][m] for m in MODELS]
    a2.barh(MODELS[::-1], wv[::-1], color=[COL[m] for m in MODELS[::-1]], edgecolor="k", lw=0.4)
    for i, v in enumerate(wv[::-1]): a2.text(v + 0.01, i, f"{v:.3f}", va="center", fontsize=7)
    a2.set_xlim(0, 1.05); a2.set_xlabel("Weight (non-negative, sum = 1)")
    a2.set_title("(b) PSO-VWCM weights at 2024", loc="left")
    fig.tight_layout(); save(fig, f"Fig{fb:02d}_{s}_accuracy_weights")

    # (c) combined forecast with 90% interval
    k = band_k(R[R.sector == s]); h = np.arange(1, len(yrs_f) + 1); z = 1.6449
    c = F[s].to_numpy(); lo, hi = c * np.exp(-z * k * np.sqrt(h)), c * np.exp(z * k * np.sqrt(h))
    fig, ax = plt.subplots(figsize=(6.6, 3.2))
    ax.plot(hist.loc[2000:].index, hist.loc[2000:], color="k", lw=1.3, label="Observed")
    ax.fill_between(yrs_f, lo, hi, color="0.8", label="90% prediction interval")
    ax.plot(yrs_f, c, color="k", ls="--", lw=1.4, label="PSO-VWCM combined forecast")
    ax.plot(2025, p25[s], "D", color="k", mfc="white", ms=4.5, label="FY2025 provisional (hold-out)")
    ax.set_xlabel("Fiscal year"); ax.set_ylabel("GWh"); ax.set_xlim(2000, 2037)
    ax.set_title(f"{NAME[s]}: combined forecast, 2025–2037", loc="left"); ax.legend(frameon=False, loc="upper left")
    ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:,.0f}"))
    save(fig, f"Fig{fc:02d}_{s}_combined_forecast")

# ------------------------------------------------------------------ Fig 27 national
fig, ax = plt.subplots(figsize=(6.8, 3.4))
ax.plot(d.loc[2000:2024].index, d.loc[2000:2024, "nat"], color="k", lw=1.3, label="Observed (six sectors)")
ax.fill_between(T11.index, T11["Baseline P5"], T11["Baseline P95"], color="0.82", label="Baseline P5–P95 (Stage 2)")
ax.plot(T11.index, T11["Stage-1 path"], color="k", ls="--", lw=1.4, label="Stage-1 PSO-VWCM path")
ax.plot(2025, p25[SECTORS].sum(), "D", color="k", mfc="white", ms=5, label="FY2025 provisional (hold-out)")
# Benchmark only (not validation): IGCEP 2025-35 (ISMO, 2025), Tables 4-8 to 4-10, country energy in 2035.
# IGCEP energy is required generation (sales + T&D losses); its FY2024 base (136,760 GWh) is rescaled to the observed
# FY2024 grid consumption (111,110 GWh), i.e. IGCEP growth is applied to our base year.
IG = pd.read_csv("igcep_2025_35_country_forecast.csv"); base = IG[IG.year == 2024].country_base_energy_GWh.iloc[0]
scale = d.loc[2024, "nat"] / base
from matplotlib.lines import Line2D
mk = {"Low BAU": "v", "Medium": "s", "High": "^"}
for sc, g in IG[IG.year == 2035].groupby("scenario"):
    ax.plot(2035.25, g.country_base_energy_GWh.iloc[0] * scale, mk[sc], color="k", mfc="0.45", ms=5)
    ax.plot(2035.25, g.country_energy_net_of_net_metering_GWh.iloc[0] * scale, mk[sc], color="k", mfc="white", ms=5)
h, l = ax.get_legend_handles_labels()
h += [Line2D([], [], marker=m, color="k", mfc="0.45", ls="none", ms=5) for m in mk.values()]
l += [f"IGCEP 2025-35 {s}, 2035 (filled: gross; open: net of net metering)" if i == 0 else f"IGCEP 2025-35 {s}, 2035" for i, s in enumerate(mk)]
ax.legend(h, l, frameon=False, loc="upper left", fontsize=6.8)
ax.set_xlabel("Fiscal year"); ax.set_ylabel("GWh"); ax.set_xlim(2000, 2037)
ax.set_title("National grid consumption: Stage-1 path and Stage-2 prediction interval", loc="left")
ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:,.0f}"))
save(fig, "Fig27_national_forecast")

# ------------------------------------------------------------------ Fig 28 shares
sh = pd.DataFrame({"FY2024 (observed)": d.loc[2024, ORDER] / d.loc[2024, ORDER].sum(),
                   "2030 (forecast)": F.loc[2030, ORDER] / F.loc[2030, ORDER].sum(),
                   "2037 (forecast)": F.loc[2037, ORDER] / F.loc[2037, ORDER].sum()}).T * 100
fig, ax = plt.subplots(figsize=(7.0, 2.4)); left = np.zeros(len(sh))
hatches = ["", "////", "", "....", "xx", "\\\\"]
for i, s in enumerate(ORDER):
    ax.barh(sh.index[::-1], sh[s][::-1], left=left[::-1], color=SECCOL[s], edgecolor="k", lw=0.3, label=NAME[s])
    for j, (v, l0) in enumerate(zip(sh[s][::-1], left[::-1])):
        if v > 4: ax.text(l0 + v / 2, j, f"{v:.1f}", ha="center", va="center", fontsize=7.5, color="k")
    left += sh[s].to_numpy()
ax.set_xlim(0, 100); ax.set_xlabel("Share of six-sector grid consumption (%)")
ax.legend(ncol=6, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.28), fontsize=7)
save(fig, "Fig28_sector_shares")

# ------------------------------------------------------------------ Figs 29-32 (simulations)
S = {n: np.load(f"sim_{n}.npz") for n in ("Baseline", "High-Heat", "Low-Heat")}
col_of = lambda z, yr: z["elec"][:, list(z["years"]).index(yr)]
tx_of = lambda z, yr: z["txx"][:, list(z["years"]).index(yr)]
def cdf_hist(v, unit, title, fname, dist):
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.8))
    xs = np.sort(v); a1.plot(xs, np.arange(1, len(xs) + 1) / len(xs), color="k", lw=1.2, label="Empirical")
    par = dist.fit(v); g = np.linspace(xs[0], xs[-1], 300); a1.plot(g, dist.cdf(g, *par), color="0.5", ls="--", label="Fitted " + {"norm": "normal", "lognorm": "lognormal"}[dist.name])
    a1.set_xlabel(unit); a1.set_ylabel("Cumulative probability"); a1.legend(frameon=False); a1.set_title(f"(a) {title}: CDF", loc="left")
    a2.hist(v, bins=60, color="0.65", edgecolor="white", lw=0.2, weights=np.full(len(v), 100 / len(v)))
    for q, ls in ((5, ":"), (50, "-"), (95, ":")): a2.axvline(np.percentile(v, q), color="k", ls=ls, lw=0.9)
    a2.set_xlabel(unit); a2.set_ylabel("Share of paths (%)")
    for a in (a1, a2): a.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:,.0f}" if abs(v) > 1000 else f"{v:g}")); a2.set_title(f"(b) {title}: P5, P50, P95", loc="left")
    fig.tight_layout(); save(fig, fname)
cdf_hist(tx_of(S["Baseline"], 2025), "TXx (°C)", "Simulated TXx, 2025", "Fig29_TXx2025_distribution", stats.norm)
cdf_hist(col_of(S["Baseline"], 2025), "GWh", "Simulated consumption, 2025", "Fig30_ELEC2025_distribution", stats.lognorm)

fig, ax = plt.subplots(2, 1, figsize=(6.6, 5.0))
sty = {"Baseline": ("k", "-."), "High-Heat": ("#D55E00", "--"), "Low-Heat": ("#0072B2", ":")}
for n, z in S.items():
    c, l = sty[n]
    for a, v, u in ((ax[0], tx_of(z, 2037), "TXx (°C)"), (ax[1], col_of(z, 2037), "GWh")):
        hgt, edges = np.histogram(v, bins=70); hgt = 100 * hgt / len(v); a.step(edges[:-1], hgt, where="post", color=c, ls=l, lw=1.2,
                                                                   label=f"{n} (median {np.median(v):,.1f})" if u.startswith("TXx") else f"{n} (median {np.median(v):,.0f})")
        a.set_xlabel(u); a.set_ylabel("Share of paths (%)")
        a.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:,.0f}" if abs(v) > 1000 else f"{v:g}"))
ax[0].set_title("(a) TXx in 2037 under the three sensitivity scenarios (±1 s.d. = ±0.98 °C by 2037)", loc="left")
ax[1].set_title("(b) National grid consumption in 2037, 20,000 paths per scenario", loc="left")
for a in ax: a.legend(frameon=False, fontsize=7)
fig.tight_layout(); save(fig, "Fig31_2037_scenario_distributions")

fig, ax = plt.subplots(figsize=(6.8, 3.4))
ax.plot(d.loc[2010:2024].index, d.loc[2010:2024, "nat"], color="k", lw=1.3, label="Observed")
ax.fill_between(T11.index, T11["Baseline P5"], T11["Baseline P95"], color="0.85", label="Baseline P5–P95")
ax.fill_between(T11.index, T11["Baseline P25"], T11["Baseline P75"], color="0.6", label="Baseline P25–P75")
for n in ("Baseline", "High-Heat", "Low-Heat"):
    c, l = sty[n]; ax.plot(T11.index, T11[f"{n} P50"], color=c, ls=l, lw=1.3, label=f"{n} median")
ax.set_xlabel("Fiscal year"); ax.set_ylabel("GWh"); ax.set_xlim(2010, 2037); ax.legend(frameon=False, loc="upper left", ncol=2)
ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:,.0f}"))
save(fig, "Fig32_fan_chart")

# ------------------------------------------------------------------ Fig 33 calibration, Fig 34 FY2025 hold-out
C = pd.read_csv("calibration.csv"); g = C.groupby("h")[["cov_mc", "cov_comb"]].mean() * 100
fig, ax = plt.subplots(figsize=(5.2, 2.8)); x = g.index.to_numpy()
ax.bar(x - 0.2, g.cov_mc, 0.4, color="0.75", edgecolor="k", lw=0.4, label="Climate and residual uncertainty only")
ax.bar(x + 0.2, g.cov_comb, 0.4, color="0.25", label="Plus Stage-1 forecast error")
ax.axhline(90, color="k", ls="--", lw=0.8); ax.text(0.55, 92, "nominal 90%", fontsize=7)
ax.set_xticks(x); ax.set_xlabel("Forecast horizon (years)"); ax.set_ylabel("Empirical coverage (%)"); ax.set_ylim(0, 115)
ax.set_title("Coverage of 90% intervals, origins 2007–2023", loc="left"); ax.legend(frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=2, fontsize=7)
save(fig, "Fig33_interval_calibration")

err = pd.Series({NAME[s]: 100 * (F.loc[2025, s] / p25[s] - 1) for s in ORDER})
err["National"] = 100 * (F.loc[2025, "national"] / p25[SECTORS].sum() - 1)
fig, ax = plt.subplots(figsize=(5.2, 2.8))
ax.barh(err.index[::-1], err.values[::-1], color=["0.2" if i == 0 else "0.6" for i in range(len(err))], edgecolor="k", lw=0.4)
for i, v in enumerate(err.values[::-1]): ax.text(v + (1 if v >= 0 else -1), i, f"{v:+.1f}%", va="center", ha="left" if v >= 0 else "right", fontsize=7)
ax.axvline(0, color="k", lw=0.6); ax.set_xlabel("FY2025 forecast error (%), relative to provisional value")
ax.set_title("FY2025 hold-out check (forecast origin FY2024)", loc="left"); ax.set_xlim(-15, 55)
save(fig, "Fig34_FY2025_holdout")

# ------------------------------------------------------------------ Supplementary S1-S2: PSO convergence and weight paths
fig, axs = plt.subplots(2, 3, figsize=(7.0, 4.2), sharex=True)
for a, s in zip(axs.ravel(), ORDER):
    df = pd.read_csv(f"rolling_{s}.csv")
    piv = df[df.model.isin(MODELS)].pivot_table(index=["origin", "h", "target"], columns="model", values="fc")[MODELS]
    piv = piv[piv.index.get_level_values("h") >= 3]
    ys = df[df.model == MODELS[0]].set_index(["origin", "h", "target"]).y.loc[piv.index]
    for seed in range(10):
        _, _, hist = pso_simplex(piv.to_numpy(), ys.to_numpy(), seed=seed); a.plot(hist, color="k", alpha=0.35, lw=0.8)
    a.set_title(NAME[s], loc="left"); a.ticklabel_format(axis="y", style="plain", useOffset=False)
for a in axs[1]: a.set_xlabel("Iteration")
for a in axs[:, 0]: a.set_ylabel("Best fitness (MSRE)")
fig.suptitle("PSO convergence at the final origin, 10 random seeds per sector", x=0.02, ha="left", fontsize=9.5)
fig.tight_layout(); save(fig, "FigS1_PSO_convergence")

fig, axs = plt.subplots(2, 3, figsize=(7.0, 4.2), sharex=True, sharey=True)
for a, s in zip(axs.ravel(), ORDER):
    Wp, _ = weights_path(pd.read_csv(f"rolling_{s}.csv"), 0.5, last=2024)
    P = pd.DataFrame(Wp, index=MODELS).T
    a.stackplot(P.index, *[P[m] for m in MODELS], colors=[COL[m] for m in MODELS], labels=MODELS, lw=0)
    a.set_title(NAME[s], loc="left"); a.set_ylim(0, 1)
axs[0, 0].legend(ncol=3, frameon=False, fontsize=6.5, loc="upper left", bbox_to_anchor=(0, 1.45))
for a in axs[1]: a.set_xlabel("Forecast origin")
for a in axs[:, 0]: a.set_ylabel("Weight")
fig.tight_layout(); save(fig, "FigS2_PSO_weight_paths")
print("figures written:", len(os.listdir("figures")) // 2)
