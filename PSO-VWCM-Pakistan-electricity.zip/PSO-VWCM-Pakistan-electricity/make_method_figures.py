#!/usr/bin/env python3
"""Figure 6: PSO procedure (Eqs. 12a-12c). Figure 7: variable-weight updating across forecast origins (Eq. 13)."""
import os, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

plt.rcParams.update({"font.family": "DejaVu Sans", "mathtext.fontset": "cm", "font.size": 10,
                     "pdf.fonttype": 42, "savefig.bbox": "tight"})
os.makedirs("figures", exist_ok=True)
INK = "#1f2d3d"
STY = {"blue": ("#eaf2fb", "#2e5c8a"), "green": ("#edf7ec", "#3d7a3a"), "orange": ("#fdf1e6", "#c0651f"),
       "grey": ("#f2f2f2", "#6b6b6b"), "white": ("#ffffff", "#2e5c8a")}

def box(ax, x, y, w, h, title, body=None, style="blue", dashed=False, fs_t=10.5, fs_b=9.8):
    fc, ec = STY[style]
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08", fc=fc, ec=ec,
                                lw=1.6, ls=(0, (4, 3)) if dashed else "-", zorder=2))
    if body is None:
        ax.text(x + w / 2, y + h / 2, title, ha="center", va="center", fontsize=fs_t, color=INK, weight="bold", zorder=3)
    else:
        ax.text(x + w / 2, y + h - 0.2, title, ha="center", va="top", fontsize=fs_t, color=INK, weight="bold", zorder=3)
        ax.text(x + w / 2, y + (h - 0.62) / 2 + 0.05, body, ha="center", va="center", fontsize=fs_b, color=INK, zorder=3,
                linespacing=1.7)

def arrow(ax, pts, color="#2e5c8a", lw=1.6, dashed=False):
    xs, ys = zip(*pts)
    ax.plot(xs, ys, color=color, lw=lw, ls=(0, (4, 3)) if dashed else "-", zorder=1)
    ax.annotate("", xy=pts[-1], xytext=pts[-2], arrowprops=dict(arrowstyle="-|>", color=color, lw=lw,
                mutation_scale=13, shrinkA=0, shrinkB=0), zorder=4)

def tag(ax, x, y, text):
    ax.text(x, y, text, ha="left", va="center", fontsize=9.5, color=INK,
            bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#9aa7b4", lw=0.8), zorder=5)

# ------------------------------------------------------------------ Figure 6: PSO procedure
fig, ax = plt.subplots(figsize=(7.6, 11.2)); ax.set_xlim(0, 11); ax.set_ylim(0, 15.6); ax.axis("off")
W, X0 = 8.4, 0.4
steps = [
    ("Inputs at forecast origin $T$",
     r"Past forecasts $F_{m,i}$ and actual values $y_i$" "\n" r"(target year $\leq T$, horizons $h = 3$–$5$)", "grey", 1.6),
    ("Initialization",
     r"40 particles, $\mathbf{x}_j \in [0,1]^6$ (random, seeded),  $\mathbf{v}_j = \mathbf{0}$", "blue", 1.3),
    ("Mapping to the probability simplex",
     r"$\mathbf{w} = \max(\mathbf{x},0) \, / \, \sum_{m} \max(x_m,0)$" "\n" r"$w_m \geq 0,\ \ \sum_m w_m = 1$;  $w_m = 0$ excludes model $m$", "blue", 1.85),
    ("Fitness evaluation  [Eq. (12a)]",
     r"$f(\mathbf{w}) = \frac{1}{N}\sum_{i}\left(\sum_{m} w_m F_{m,i} / y_i - 1\right)^{2}$", "green", 1.55),
    ("Update personal and global bests",
     r"$\mathbf{p}_j$ = best position of particle $j$;  $\mathbf{g}$ = best position of the swarm", "green", 1.3),
    ("Velocity and position update  [Eqs. (12b)–(12c)]",
     r"$\mathbf{v}_j \leftarrow 0.729\,\mathbf{v}_j + 1.494\,r_1(\mathbf{p}_j-\mathbf{x}_j) + 1.494\,r_2(\mathbf{g}-\mathbf{x}_j)$" "\n"
     r"$\mathbf{x}_j \leftarrow \min\{\max(\mathbf{x}_j+\mathbf{v}_j,\,0),\,1\}$", "orange", 1.9),
    ("Stopping and restarts",
     "200 iterations per run; five independent runs;\nthe run with the lowest fitness is retained", "orange", 1.6),
    ("Output", r"Optimal weights $\mathbf{h}(T)$, passed to Eq. (13)", "white", 1.2),
]
y = 15.4; tops = []
for i, (t, b, st, h) in enumerate(steps):
    y -= h
    box(ax, X0, y, W, h, t, b, st, dashed=(st == "grey"))
    tops.append((y, h))
    if i < len(steps) - 1:
        arrow(ax, [(X0 + W / 2, y), (X0 + W / 2, y - 0.28)]); y -= 0.28
# loop: from velocity update back to mapping (repeat until 200 iterations)
yv, hv = tops[5]; ym, hm = tops[2]
arrow(ax, [(X0 + W, yv + hv / 2), (X0 + W + 0.6, yv + hv / 2), (X0 + W + 0.6, ym + hm / 2), (X0 + W, ym + hm / 2)], dashed=True)
ax.text(X0 + W + 1.15, (yv + hv / 2 + ym + hm / 2) / 2, "repeat until 200 iterations", rotation=90, ha="center", va="center", fontsize=9, color=INK)
fig.savefig("figures/Fig06_PSO_flowchart.pdf"); fig.savefig("figures/Fig06_PSO_flowchart.png", dpi=600); plt.close(fig)

# ------------------------------------------------------------------ Figure 7: variable-weight updating
fig, ax = plt.subplots(figsize=(8.2, 9.6)); ax.set_xlim(0, 11.6); ax.set_ylim(0, 13.4); ax.axis("off")
XC, WB = 0.4, 8.6
box(ax, XC, 11.4, WB, 1.7, "Initialization at the first origin ($T$ = 1996)",
    r"$w_m(T) = h_m(T) = \frac{1}{M} = \frac{1}{6}, \quad \forall\, m \in [1, M]$", "blue")
box(ax, 0.1, 9.05, 4.3, 1.55, "Inputs",
    r"$F_{m,i},\ y_i$  for past cases with" "\n" r"target year $\leq T$ and $h = 3$–$5$", "grey", dashed=True, fs_b=10)
box(ax, XC, 6.2, WB, 2.3, "Determination of $\\mathbf{h}(T)$ by PSO  [Eq. (12)]",
    r"$\mathbf{h}(T) = \arg\min_{\mathbf{w}} \frac{1}{N}\sum_{i}\left(\frac{\sum_m w_m F_{m,i}}{y_i}-1\right)^{2}$" "\n"
    r"subject to  $w_m \geq 0,\ \sum_m w_m = 1$", "green")
box(ax, XC, 3.6, WB, 1.75, "Determination of $\\mathbf{w}(T)$  [Eq. (13)]",
    r"$w_m(T) = \beta\, w_m(T-1) + (1-\beta)\, h_m(T), \quad \beta = 0.5$", "orange")
box(ax, XC, 0.2, WB, 2.55, "Combined forecast from origin $T$",
    r"$\hat{Y}(T+h) = \sum_{m=1}^{M} w_m(T)\, F_m(T+h)$" "\n"
    r"$h = 1$–$5$ for evaluation ($T$ = 2007–2023)" "\n" r"$h = 1$–$13$ for the final forecast ($T$ = 2024)", "white")
mid = XC + WB / 2
arrow(ax, [(mid, 11.4), (mid, 8.5)])
arrow(ax, [(4.4, 9.82), (mid - 0.02, 9.82)], dashed=True)
arrow(ax, [(mid, 6.2), (mid, 5.35)])
arrow(ax, [(mid, 3.6), (mid, 2.75)])
tag(ax, mid + 0.15, 10.9, r"$\mathbf{w}(T-1)$")
tag(ax, mid + 0.15, 5.78, r"$\mathbf{h}(T)$")
tag(ax, mid + 0.15, 3.18, r"$\mathbf{w}(T)$")
# loop to next origin
arrow(ax, [(XC + WB, 4.47), (XC + WB + 0.8, 4.47), (XC + WB + 0.8, 9.82), (mid + 0.02, 9.82)], dashed=True)
ax.text(XC + WB + 1.45, 7.1, r"next origin $T+1$ (new errors observed)", rotation=90, ha="center", va="center", fontsize=9, color=INK)
fig.savefig("figures/Fig07_weight_updating.pdf"); fig.savefig("figures/Fig07_weight_updating.png", dpi=600); plt.close(fig)
print("done")
