#!/usr/bin/env python3
"""Vector LSTM diagrams (Figures 2-4), drawn with the notation of Eqs. (6a)-(6b).
Fig 2: gates computed from [h_{s-1}, r_s]; Fig 3: memory-cell update; Fig 4: complete cell with hidden output."""
import os, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, Ellipse

plt.rcParams.update({"font.family": "DejaVu Sans", "mathtext.fontset": "cm", "font.size": 10,
                     "pdf.fonttype": 42, "savefig.bbox": "tight"})
os.makedirs("figures", exist_ok=True)
BOX, OP, LINE, HI = "#c9d6e3", "#e6e6e6", "#222222", "#b03a2e"
Y_MEM, Y_HID, Y_GATE, Y_MID = 5.6, 1.9, 3.2, 4.45
X_F, X_I, X_C, X_O = 3.0, 4.65, 6.3, 7.95

def arrow(ax, pts, color=LINE, lw=1.4, head=True):
    xs, ys = zip(*pts)
    ax.plot(xs[:-1] + (xs[-1],), ys[:-1] + (ys[-1],), color=color, lw=lw, solid_capstyle="round", zorder=1)
    if head:
        ax.annotate("", xy=pts[-1], xytext=pts[-2],
                    arrowprops=dict(arrowstyle="-|>", color=color, lw=lw, mutation_scale=12, shrinkA=0, shrinkB=0), zorder=2)

def box(ax, x, y, label, color=BOX):
    ax.add_patch(FancyBboxPatch((x - 0.42, y - 0.3), 0.84, 0.6, boxstyle="round,pad=0.02,rounding_size=0.06",
                                fc=color, ec=LINE, lw=1.1, zorder=3))
    ax.text(x, y, label, ha="center", va="center", fontsize=12, zorder=4)

def op(ax, x, y, label):
    ax.add_patch(Circle((x, y), 0.24, fc=OP, ec=LINE, lw=1.1, zorder=3))
    ax.text(x, y, label, ha="center", va="center", fontsize=12, zorder=4)

def draw(stage, name, caption_hint):
    fig, ax = plt.subplots(figsize=(8.2, 4.4))
    ax.set_xlim(-0.2, 12.4); ax.set_ylim(-0.9, 6.7); ax.axis("off")
    ax.add_patch(FancyBboxPatch((1.6, 1.15), 8.9, 5.0, boxstyle="round,pad=0.02,rounding_size=0.35",
                                fc="white", ec=LINE, lw=1.5, zorder=0))
    # inputs: hidden state and input concatenated, then copied to each layer
    ax.text(0.0, Y_HID + 0.28, r"Hidden state $\mathbf{h}_{s-1}$", ha="left", va="bottom")
    ax.text(2.25, -0.55, r"Input $r_s$", ha="center", va="top")
    arrow(ax, [(0.0, Y_HID), (X_O, Y_HID)], head=False)
    arrow(ax, [(2.25, -0.35), (2.25, Y_HID)], head=False)
    for x in (X_F, X_I, X_C, X_O):
        arrow(ax, [(x, Y_HID), (x, Y_GATE - 0.3)])
    # gate layers
    box(ax, X_F, Y_GATE, r"$\sigma$"); box(ax, X_I, Y_GATE, r"$\sigma$")
    box(ax, X_C, Y_GATE, r"$\tanh$"); box(ax, X_O, Y_GATE, r"$\sigma$")
    lab = dict(fontsize=8.5, ha="right", va="center", linespacing=1.15)
    for x, t, sym in ((X_F, "Forget\ngate", r"$\mathbf{f}_s$"), (X_I, "Input\ngate", r"$\mathbf{i}_s$"),
                      (X_C, "Candidate\nmemory", r"$\tilde{\mathbf{c}}_s$"), (X_O, "Output\ngate", r"$\mathbf{o}_s$")):
        ax.text(x - 0.12, Y_GATE + 0.78, t, **lab)
        ax.text(x + 0.12, Y_GATE + 0.52, sym, ha="left", va="center", fontsize=11)
    # memory line
    ax.text(0.0, Y_MEM + 0.28, r"Memory $\mathbf{c}_{s-1}$", ha="left", va="bottom")
    if stage == 1:
        for x in (X_F, X_I, X_C, X_O):
            arrow(ax, [(x, Y_GATE + 0.3), (x, Y_MID + 0.35)])
        arrow(ax, [(0.0, Y_MEM), (11.2, Y_MEM)], color="#9a9a9a", head=False)
    else:
        col = HI if stage == 2 else LINE
        arrow(ax, [(0.0, Y_MEM), (X_F - 0.24, Y_MEM)])
        op(ax, X_F, Y_MEM, r"$\odot$")
        arrow(ax, [(X_F, Y_GATE + 0.3), (X_F, Y_MEM - 0.24)], color=col)
        arrow(ax, [(X_F + 0.24, Y_MEM), (X_C - 0.24, Y_MEM)])
        op(ax, X_C, Y_MEM, r"$+$")
        op(ax, X_C, Y_MID, r"$\odot$")
        arrow(ax, [(X_C, Y_GATE + 0.3), (X_C, Y_MID - 0.24)], color=col)
        arrow(ax, [(X_I, Y_GATE + 0.3), (X_I, Y_MID), (X_C - 0.24, Y_MID)], color=col)
        arrow(ax, [(X_C, Y_MID + 0.24), (X_C, Y_MEM - 0.24)], color=col)
        arrow(ax, [(X_C + 0.24, Y_MEM), (11.2, Y_MEM)], color=col)
        ax.text(11.3, Y_MEM, r"$\mathbf{c}_s$", ha="left", va="center", fontsize=12)
        if stage == 2:
            arrow(ax, [(X_O, Y_GATE + 0.3), (X_O, Y_MID + 0.35)])
    if stage == 3:
        # output path: h_s = o_s (.) tanh(c_s)
        X_T, Y_OUT = 9.2, Y_MID - 0.15
        arrow(ax, [(X_T, Y_MEM), (X_T, Y_MEM - 0.42)], color=HI)
        ax.add_patch(Ellipse((X_T, Y_MEM - 0.64), 0.9, 0.44, fc=OP, ec=LINE, lw=1.1, zorder=3))
        ax.text(X_T, Y_MEM - 0.64, r"$\tanh$", ha="center", va="center", fontsize=11, zorder=4)
        arrow(ax, [(X_T, Y_MEM - 0.86), (X_T, Y_OUT + 0.24)], color=HI)
        op(ax, X_T, Y_OUT, r"$\odot$")
        arrow(ax, [(X_O, Y_GATE + 0.3), (X_O, Y_OUT), (X_T - 0.24, Y_OUT)], color=HI)
        arrow(ax, [(X_T + 0.24, Y_OUT), (10.05, Y_OUT), (10.05, 1.45), (11.2, 1.45)], color=HI)
        ax.text(11.3, 1.45, r"$\mathbf{h}_s$", ha="left", va="center", fontsize=12)
    # legend
    ly = -0.55
    ax.add_patch(FancyBboxPatch((4.1, ly - 0.2), 0.5, 0.4, boxstyle="round,pad=0.02,rounding_size=0.05", fc=BOX, ec=LINE, lw=1))
    ax.text(4.35, ly, r"$\sigma$", ha="center", va="center", fontsize=10)
    ax.text(4.75, ly, "Fully connected layer with activation", va="center", fontsize=8.5)
    ax.add_patch(Circle((9.1, ly), 0.18, fc=OP, ec=LINE, lw=1))
    ax.text(9.4, ly, "Element-wise operation", va="center", fontsize=8.5)
    fig.savefig(f"figures/{name}.pdf"); fig.savefig(f"figures/{name}.png", dpi=600); plt.close(fig)

draw(1, "Fig02_LSTM_gates", "gates")
draw(2, "Fig03_LSTM_memory_update", "memory update")
draw(3, "Fig04_LSTM_cell", "complete cell")
print("done")
