import pandas as pd, json
from combine import metrics
from stage1_rolling import MODELS, EVAL_FROM
R=pd.read_csv('combined_forecasts.csv'); W=json.load(open('weights.json'))['final_weights']
L={'res':('Table 3','Residential'),'agr':('Table 4','Agricultural'),'com':('Table 5','Commercial'),'ind':('Table 6','Industrial'),'sl':('Table 7','Street lighting'),'og':('Table 8','Other government')}
cols=MODELS+["PSO-VWCM (beta=0.5)","Equal weights","Naive"]; nm={"PSO-VWCM (beta=0.5)":"PSO-VWCM","Equal weights":"Equal wts","Naive":"RW-drift","Holt":"Holt"}
ev=R[R.origin>=EVAL_FROM]; out=[]
def fmt(v,k): return f"{v:,.1f}" if k in("MAE","RMSE") else (f"{v:.2f}" if k=="MAPE (%)" else f"{v:.3f}")
def block(title,sub,key):
    m1=metrics(sub[sub.h==1],cols); m5=metrics(sub,cols)
    t=pd.DataFrame({nm.get(c,c):[fmt(m1.loc[c,k],k) for k in ["MAE","RMSE","MAPE (%)","NRMSE","RAE"]]+[fmt(m5.loc[c,"MAPE (%)"],"MAPE (%)"),fmt(m5.loc[c,"RAE"],"RAE")] for c in cols},
        index=["MAE (GWh), h=1","RMSE (GWh), h=1","MAPE (%), h=1","NRMSE, h=1","RAE, h=1","MAPE (%), h=1–5","RAE, h=1–5"])
    if key: t.loc["Weight at 2024"]=[f"{W[key][c]:.3f}" if c in MODELS else ("—") for c in cols]
    return f"\n**{title}**\n\n"+t.to_markdown(disable_numparse=True)+f"\n\n*Note.* Out-of-sample forecasts from expanding-window origins 2007–2023 (h=1: n={len(sub[sub.h==1])}; h=1–5 pooled: n={len(sub)}). NRMSE = RMSE/(max − min of actuals); RAE = Σ|e| / Σ|e of RW-drift|. Weights are non-negative and sum to one; a zero weight means the model is excluded.\n"
for s in ['res','agr','com','ind','sl','og']: out.append(block(f"{L[s][0]}. {L[s][1]} sector: out-of-sample forecast accuracy",ev[ev.sector==s],s))
nat=ev.groupby(["origin","h","target"])[cols+["y"]].sum().reset_index()
out.append(block("New table. National consumption (sum of six sectors): out-of-sample forecast accuracy",nat,None))
open('tables_3_8_revised.md','w').write("\n".join(out))
