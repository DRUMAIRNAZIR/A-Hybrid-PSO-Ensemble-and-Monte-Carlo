import json, numpy as np, pandas as pd
import stage1_rolling as s
d = pd.read_csv("sector_data_harmonised.csv").set_index("year")
W = json.load(open("weights.json"))["final_weights"]
yrs = np.arange(2025, 2038); out = {}; cfg = {}
for sec in s.SECTORS:
    y = d.loc[:2024, sec].to_numpy(float); F = []
    for m in s.MODELS:
        fc, info = s.FUN[m](y, 13); F.append(fc); cfg[f"{sec}-{m}"] = info
    F = np.array(F).T; w = np.array([W[sec][m] for m in s.MODELS])
    out[sec] = F @ w
    for j, m in enumerate(s.MODELS): out[f"{sec}_{m}"] = F[:, j]
R = pd.DataFrame(out, index=yrs); R["national"] = R[s.SECTORS].sum(1)
R.to_csv("final_forecasts_2023_2037.csv")
json.dump(cfg, open("final_model_config.json", "w"), default=str, indent=1)
base = d.loc[2024]
print(R[s.SECTORS + ["national"]].loc[[2025, 2030, 2037]].round(0).to_string())
print("2024 actual:", {k: int(base[k]) for k in s.SECTORS}, "six-sector sum", int(base[s.SECTORS].sum()))
g = {k: round(100 * (R.loc[2037, k] / base[k] - 1), 1) for k in s.SECTORS + []}
print("cum growth 2024-2037 %:", g, "national", round(100 * (R.loc[2037, "national"] / base[s.SECTORS].sum() - 1), 1))
print("CAGR national %:", round(100 * ((R.loc[2037, "national"] / base[s.SECTORS].sum()) ** (1 / 13) - 1), 2))
sh = (R.loc[2037, s.SECTORS] / R.loc[2037, "national"] * 100).round(2); print("2037 shares:", sh.to_dict())

print({k: v for k, v in cfg.items() if k.endswith(("ARIMA", "Holt", "SVR"))})
