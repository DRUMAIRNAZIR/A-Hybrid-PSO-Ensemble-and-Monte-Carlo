#!/usr/bin/env python3
"""Stage 2 (final): Table 11 and simulated distributions used in Figs 29-32. See stage2_mc_core.py."""
import numpy as np, pandas as pd
from stage2_mc_core import estimate, simulate
M = "PSO-VWCM (beta=0.5)"
R = pd.read_csv("combined_forecasts.csv"); nat = R.groupby(["origin", "h", "target"])[[M, "y"]].sum().reset_index()
sd = np.log(nat.y / nat[M]).groupby(nat.h).std(); k = float(np.sum(sd * np.sqrt(sd.index)) / np.sum(sd.index))
hist = pd.read_csv("history.csv"); s1 = pd.read_csv("final_forecasts_2023_2037.csv", index_col=0)["national"]
fit = estimate(hist); SHIFT = hist.txx.std(ddof=1)
print("k =", round(k, 4), " TXx shift =", round(SHIFT, 3)); print(fit.params.round(1).to_dict())
rng = np.random.default_rng(20260922); out = {}
for name, sh in [("Baseline", 0.0), ("High-Heat", SHIFT), ("Low-Heat", -SHIFT)]:
    E, TX = simulate(fit, hist, s1, 20000, sh, rng, k=k, return_txx=True)
    np.savez_compressed(f"sim_{name}.npz", years=E.columns.to_numpy(), elec=E.to_numpy(), txx=TX.to_numpy())
    for yr in s1.index:
        out.setdefault(yr, {}).update({f"{name} P{p}": np.percentile(E[yr], p) for p in (5, 25, 50, 75, 95)})
T = pd.DataFrame(out).T; T.insert(0, "Stage-1 path", s1); T["Spread H-L P50"] = T["High-Heat P50"] - T["Low-Heat P50"]
T.round(0).to_csv("table11_revised_combined.csv")
cols = ["Stage-1 path"] + [f"{s} P{p}" for s in ("Baseline", "High-Heat", "Low-Heat") for p in (5, 50, 95)] + ["Spread H-L P50"]
print(T.loc[[2025, 2030, 2037], cols].round(0).astype(int).T.to_string())
