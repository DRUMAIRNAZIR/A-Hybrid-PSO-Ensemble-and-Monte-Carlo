#!/usr/bin/env python3
"""Vector framework diagram (manuscript Figure 2)."""
import os, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle
os.makedirs("figures", exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "pdf.fonttype": 42, "savefig.bbox": "tight"})

def box(ax, x, y, w, h, text, fc="white", bold=False, fs=6.9):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.06", fc=fc, ec="k", lw=0.8))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, weight="bold" if bold else "normal", wrap=True)
def arrow(ax, x0, y0, x1, y1):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0), arrowprops=dict(arrowstyle="-|>", lw=0.9, color="k", shrinkA=0, shrinkB=0))
def save(fig, name):
    fig.savefig(f"figures/{name}.pdf"); fig.savefig(f"figures/{name}.png", dpi=600); plt.close(fig)

# ---------------------------------------------------------------- Fig 2
fig, ax = plt.subplots(figsize=(9.0, 6.0)); ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")
ax.add_patch(FancyBboxPatch((0.1, 5.25), 9.8, 4.6, boxstyle="round,pad=0.02", fc="0.96", ec="0.5", lw=0.6, ls="--"))
ax.add_patch(FancyBboxPatch((0.1, 0.15), 9.8, 4.75, boxstyle="round,pad=0.02", fc="0.96", ec="0.5", lw=0.6, ls="--"))
ax.text(0.25, 9.6, "Stage 1: sectoral forecasting and PSO combination", weight="bold", fontsize=8.5)
ax.text(0.25, 4.62, "Stage 2: heat sensitivity and probabilistic simulation (national)", weight="bold", fontsize=8.5)
box(ax, 0.3, 8.1, 2.6, 1.1, "Sectoral grid consumption\nFY1972–FY2024, six sectors\n(PES Tables 12.1, 14.1)")
box(ax, 3.4, 8.1, 3.3, 1.1, "Six base models on log level / growth\nSVR · BPNN · LSTM · Holt (no season)\nARIMA(p,1,q) · GM(1,1)")
box(ax, 7.2, 8.1, 2.5, 1.1, "Expanding-window rolling origin\norigins 1996–2023\nh = 1–5 years")
box(ax, 0.3, 6.0, 3.0, 1.5, "PSO on the simplex\nmin mean squared relative error\nof past combined forecasts\n(errors with target ≤ origin, h ≥ 3)")
box(ax, 3.8, 6.0, 2.7, 1.5, "Variable weights\nw(T) = β w(T−1) + (1−β) h(T)\nβ = 0.5;  w ≥ 0,  Σw = 1")
box(ax, 7.0, 6.0, 2.7, 1.5, "Out-of-sample evaluation\norigins 2007–2023 vs equal\nweights, best single, RW-drift\nFY2025 hold-out")
arrow(ax, 2.9, 8.65, 3.4, 8.65); arrow(ax, 6.7, 8.65, 7.2, 8.65); arrow(ax, 8.45, 8.1, 8.45, 7.5)
arrow(ax, 7.0, 6.75, 6.5, 6.75); arrow(ax, 3.8, 6.75, 3.3, 6.75)
box(ax, 3.4, 5.4, 3.4, 0.45, "Sector forecasts 2025–2037 → national path Ŷ(t) = Σ sectors", fc="0.88", fs=7.3)
arrow(ax, 5.1, 6.0, 5.1, 5.85)
box(ax, 0.3, 2.9, 3.0, 1.35, "ERA5 daily Tmax → TXx\n1974–2024, Pakistan\n(Hersbach et al., 2020)")
box(ax, 3.8, 2.9, 2.8, 1.35, "OLS, Newey–West HAC(1)\nΔELEC on ΔTXx, ΔTXx(t−1)\nn = 49; robustness (Table 9b)")
box(ax, 7.0, 2.9, 2.7, 1.35, "TXx scenarios (sensitivity)\nBaseline, ±0.98 °C (±1 s.d.)\nphased in to 2037\nnot GCM projections")
box(ax, 0.3, 0.45, 5.9, 1.95, "Monte Carlo, 20,000 paths per scenario\nELEC(t) = Ŷ(t)·exp(u(t)) + D(t)\nD: TXx levels drawn i.i.d., coefficients from N(β̂, V_HAC), residual shocks\nu: Stage-1 error, s.d. = k√h, k from out-of-sample errors")
box(ax, 6.7, 0.45, 3.0, 1.95, "Outputs\nP5–P95 intervals (Table 11)\ncalibration check, origins\n2007–2023 (Fig. 33)")
arrow(ax, 3.3, 3.55, 3.8, 3.55); arrow(ax, 5.2, 2.9, 5.2, 2.4); arrow(ax, 8.35, 2.9, 5.9, 2.4); arrow(ax, 6.2, 1.4, 6.7, 1.4)
arrow(ax, 3.55, 5.4, 3.55, 2.4)
save(fig, "Fig02_framework")

print("framework figure done")
