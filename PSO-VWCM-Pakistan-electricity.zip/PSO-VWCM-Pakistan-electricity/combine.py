#!/usr/bin/env python3
import json, numpy as np, pandas as pd
from stage1_rolling import pso_simplex, SECTORS, MODELS, FIRST_ORIGIN, EVAL_FROM

BETA = 0.5
RESTARTS = 5
LAB = {"res": "Residential", "agr": "Agricultural", "com": "Commercial", "ind": "Industrial",
       "sl": "Street lighting", "og": "Other government"}

def weights_path(df, beta, seed=0, last=2024, hmin=3):
    """Return {origin: weight vector} using only errors with target <= origin."""
    piv = df[df.model.isin(MODELS)].pivot_table(index=["origin", "h", "target"], columns="model", values="fc")[MODELS]
    ys = df[df.model == MODELS[0]].set_index(["origin", "h", "target"]).y
    W, w_prev, hist_best = {}, None, {}
    for T in range(FIRST_ORIGIN, last + 1):
        past = piv[(piv.index.get_level_values("target") <= T) & (piv.index.get_level_values("h") >= hmin)]
        if len(past) < 3:
            h_T = np.full(len(MODELS), 1 / len(MODELS))
        else:
            # multi-start: best of RESTARTS independent swarms (single runs reach the best optimum in 7-9 of 10 seeds)
            runs = [pso_simplex(past.to_numpy(), ys.loc[past.index].to_numpy(), seed=seed + r) for r in range(RESTARTS)]
            h_T = min(runs, key=lambda z: z[1])[0]
        w = h_T if w_prev is None else beta * w_prev + (1 - beta) * h_T
        W[T] = w; w_prev = w
        # best single model on past relative errors (benchmark)
        if len(past):
            e = ((past.to_numpy() / ys.loc[past.index].to_numpy()[:, None]) - 1) ** 2
            hist_best[T] = MODELS[int(e.mean(0).argmin())]
        else:
            hist_best[T] = "ARIMA"
    return W, hist_best

def combos(df, W0, W5, best, W5p):
    piv = df[df.model.isin(MODELS)].pivot_table(index=["origin", "h", "target"], columns="model", values="fc")[MODELS]
    ys = df[df.model == MODELS[0]].set_index(["origin", "h", "target"]).y
    F = piv.to_numpy(); O = piv.index.get_level_values("origin")
    past_err = {}
    out = {m: piv[m] for m in MODELS}
    out["Naive"] = df[df.model == "Naive"].set_index(["origin", "h", "target"]).fc.loc[piv.index]
    out["Equal weights"] = pd.Series(F.mean(1), index=piv.index)
    out["PSO-VWCM (beta=0.5)"] = pd.Series([F[i] @ W5[o] for i, o in enumerate(O)], index=piv.index)
    out["PSO static (beta=0)"] = pd.Series([F[i] @ W0[o] for i, o in enumerate(O)], index=piv.index)
    out["PSO-VWCM, weights from h=1-5"] = pd.Series([F[i] @ W5p[o] for i, o in enumerate(O)], index=piv.index)
    out["Best past single"] = pd.Series([piv.iloc[i][best[o]] for i, o in enumerate(O)], index=piv.index)
    res = pd.DataFrame(out); res["y"] = ys.loc[piv.index]; return res.reset_index()

def metrics(r, cols, naive="Naive"):
    rows = {}
    for c in cols:
        e = r[c] - r.y
        rmse = np.sqrt(np.mean(e ** 2))
        rows[c] = {"MAE": np.mean(abs(e)), "RMSE": rmse, "MAPE (%)": 100 * np.mean(abs(e) / r.y),
                   "NRMSE": rmse / (r.y.max() - r.y.min()),
                   "RAE": abs(e).sum() / abs(r[naive] - r.y).sum()}
    return pd.DataFrame(rows).T

if __name__ == "__main__":
    allres, W_final, stab = [], {}, {}
    for s in SECTORS:
        df = pd.read_csv(f"rolling_{s}.csv")
        W5, best = weights_path(df, BETA, last=2023)
        W5p, _ = weights_path(df, BETA, last=2023, hmin=1)
        W0, _ = weights_path(df, 0.0, last=2023)
        r = combos(df, W0, W5, best, W5p); r["sector"] = s; allres.append(r)
        # weights at 2022 (all errors up to 2022) for the final forecast, and seed stability of the PSO step
        Wf, _ = weights_path(df, BETA, last=2024); W_final[s] = dict(zip(MODELS, np.round(Wf[2024], 4)))
        Wp, _ = weights_path(df, BETA, last=2024, hmin=1); W_final[s+"_h1to5"] = dict(zip(MODELS, np.round(Wp[2024], 4)))
        piv = df[df.model.isin(MODELS)].pivot_table(index=["origin", "h", "target"], columns="model", values="fc")[MODELS]
        piv = piv[piv.index.get_level_values("h") >= 3]
        ys = df[df.model == MODELS[0]].set_index(["origin", "h", "target"]).y.loc[piv.index]
        sol = np.array([pso_simplex(piv.to_numpy(), ys.to_numpy(), seed=k)[0] for k in range(10)])
        stab[s] = {"mean": dict(zip(MODELS, sol.mean(0).round(4))), "sd": dict(zip(MODELS, sol.std(0).round(4)))}
        print(s, "weights@2022:", W_final[s], flush=True)
    R = pd.concat(allres); R.to_csv("combined_forecasts.csv", index=False)
    json.dump({"final_weights": W_final, "pso_seed_stability_h_T2022": stab}, open("weights.json", "w"), indent=1)
    methods = MODELS + ["Naive", "Equal weights", "Best past single", "PSO static (beta=0)", "PSO-VWCM, weights from h=1-5", "PSO-VWCM (beta=0.5)"]
    ev = R[R.origin >= EVAL_FROM]
    with open("metrics.txt", "w") as fh:
        for hsel, lab in [([1], "h=1"), ([1, 2, 3, 4, 5], "h=1-5 pooled")]:
            for s in SECTORS:
                m = metrics(ev[(ev.sector == s) & ev.h.isin(hsel)], methods)
                fh.write(f"\n### {LAB[s]}  [{lab}]  n={len(ev[(ev.sector == s) & ev.h.isin(hsel)])}\n{m.round(3).to_string()}\n")
            nat = ev[ev.h.isin(hsel)].groupby(["origin", "h", "target"])[methods + ["y"]].sum().reset_index()
            m = metrics(nat, methods); fh.write(f"\n### NATIONAL (sum of six sectors) [{lab}] n={len(nat)}\n{m.round(3).to_string()}\n")
    print(open("metrics.txt").read())
